package com.amrita.jpl.cys21028.p2;
import java.util.Scanner;

/**
 * The QuizGameClient class extends the QuizGame class and represents the client-side
 * functionality of the quiz game.
 */
public class QuizGameClient extends QuizGame implements QuizGameListener {
    private QuizGameServer server;

    /**
     * Constructs a QuizGameClient object with the specified server.
     *
     * @param server the server to connect to
     */
    public QuizGameClient(QuizGameServer server) {
        this.server = server;
        server.addListener(this);
    }

    /**
     * Starts the quiz game.
     */
    void startGame() {
        server.startGame();
    }

    /**
     * Asks a question.
     */
    void askQuestion() {
        // This method is implemented by the server; clients receive the question via onQuestionAsked()
    }

    /**
     * Evaluates the given answer.
     *
     * @param answer the answer provided by the client
     */
    @Override
    void evaluateAnswer(String answer) {
        server.evaluateAnswer(answer);
    }

    /**
     * Called when the server asks a question.
     *
     * @param question the question asked by the server
     */
    @Override
    public void onQuestionAsked(String question) {
        System.out.println("Question: " + question);
        Scanner scanner = new Scanner(System.in);
        String answer = scanner.nextLine();

        evaluateAnswer(answer);
    }

    /**
     * Called when the server evaluates an answer.
     *
     * @param isCorrect true if the answer is correct, false otherwise
     */
    @Override
    public void onAnswerEvaluated(boolean isCorrect) {
        if (isCorrect) {
            System.out.println("Your answer is correct!");
        } else {
            System.out.println("Your answer is incorrect.");
        }
        // Display the result to the client

        // Ask the next question
        askQuestion();
    }
}
