package com.amrita.jpl.cys21028.p2;
/**
 * Quiz game between client and server
 */

public class Main {
    public static void main(String[] args) {
        QuizGameServer server = new QuizGameServer();
        QuizGameClient client = new QuizGameClient(server);

        server.addQuestion("What is your name?");
        server.addQuestion("Who is the president of india?");

        client.startGame();
    }
}
