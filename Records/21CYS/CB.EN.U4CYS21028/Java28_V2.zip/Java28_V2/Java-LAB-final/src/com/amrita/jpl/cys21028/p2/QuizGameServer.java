package com.amrita.jpl.cys21028.p2;
import java.util.*;
import java.net.*;
/**
 * The QuizGame abstract class represents a quiz game and defines the basic methods
 * that should be implemented by its subclasses.
 */
 abstract class QuizGame {

    abstract void startGame();

    abstract void askQuestion();

    /**
     *
     * @param answer the answer provided by the player
     */
    abstract void evaluateAnswer(String answer);
}

/**
 * The QuizGameListener interface defines the methods to be implemented by classes
 * that listen to the quiz game events.
 */
 interface QuizGameListener {

    /**
     *
     * @param question the question asked by the server
     */
    void onQuestionAsked(String question);

    /**
     *
     * @param isCorrect true if the answer is correct, false otherwise
     */
    void onAnswerEvaluated(boolean isCorrect);
}


public class QuizGameServer extends QuizGame {
    private List<QuizGameListener> listeners;
    private List<String> questions;
    private Random random;
    private int currentQuestionIndex;

    /**
     * Constructs a QuizGameServer object.
     */
    public QuizGameServer() {
        listeners = new ArrayList<>();
        questions = new ArrayList<>();
        random = new Random();
        currentQuestionIndex = -1;
    }

    /**
     *
     * @param listener the listener to be added
     */
    public void addListener(QuizGameListener listener) {
        listeners.add(listener);
    }

    /**
     *
     * @param question the question to be added
     */
    public void addQuestion(String question) {
        questions.add(question);
    }

    /**
     * Starts the quiz game.
     */
    public void startGame() {
        askQuestion();
    }

    /**
     * Asks a question to the clients.
     */
    public void askQuestion() {
        currentQuestionIndex++;
        if (currentQuestionIndex < questions.size()) {
            String question = questions.get(currentQuestionIndex);
            for (QuizGameListener listener : listeners) {
                listener.onQuestionAsked(question);
            }
        } else {
            System.out.println("All questions have been asked. Game over!");
        }
    }

    /**
     *
     * @param answer the answer provided by a client
     */
    public void evaluateAnswer(String answer) {
        boolean isCorrect = false;
        if (currentQuestionIndex == 0 && answer.equalsIgnoreCase("Hitesh")) {
            isCorrect = true;
        } else if (currentQuestionIndex == 1 && answer.equalsIgnoreCase("Droupadi Murmu")) {
            isCorrect = true;
        }

        for (QuizGameListener listener : listeners) {
            listener.onAnswerEvaluated(isCorrect);
        }
    }
}
