package com.amrita.jpl.cys21028.Practice.operations;

public class Addition {
    public static void main(String[] args) {
        /**
         * @param args is used to take arguements
         *
         */
        int a = 5;
        int b = 10;
        int c = a+b;
        System.out.println(c);
    }
}